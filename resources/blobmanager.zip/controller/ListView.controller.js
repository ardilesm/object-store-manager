sap.ui.define(["sap/ui/core/mvc/Controller"],e=>{"use strict";return e.extend("blobmanager.controller.ListView",{onInit(){}})});
//# sourceMappingURL=ListView.controller.js.map