sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  "use strict";

  return BaseController.extend("blobmanager.controller.App", {
      onInit() {
      }
  });
});